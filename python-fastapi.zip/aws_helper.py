import os
import json
import boto3
import pprint




class aws_Core:
    def __init__(self,key,secrete,token):
        # print("class init", key,secrete,token)
        os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
        self.ec2 = boto3.client('ec2',
                                aws_access_key_id=key,
                                aws_secret_access_key=secrete,
                                aws_session_token=token)
        
        self.rds_client = boto3.client('rds',
                                aws_access_key_id=key,
                                aws_secret_access_key=secrete,
                                aws_session_token=token)
        
        self.boto3_session_token_service = boto3.client('sts',
                                aws_access_key_id=key,
                                aws_secret_access_key=secrete,
                                aws_session_token=token)



    

    async def get_rds_vpcSecurityId(self):
        # ec2 = boto3.client('ec2')
        response = self.ec2.describe_vpcs()
        VPCs = []
        for vpc in response['Vpcs']:
            vpc_id = vpc['VpcId']
            vpc_name = ''            
            for tag in vpc['Tags']:
                if tag['Key'] == 'Name':
                    vpc_name = tag['Value']
                    break  

            VPCs.append({
                "vpc_id":vpc_id,
                "vpc_name":vpc_name
            })
        # pprint.pprint(VPCs)
        for vpc_id in VPCs:
            vpc_sg_group = []
            # ec2 = boto3.client('ec2')
            response = self.ec2.describe_security_groups(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id['vpc_id']]}])

            for group in response['SecurityGroups']:
                group_id = group['GroupId']
                group_name = group['GroupName']
                vpc_sg_group.append(
                    {
                        "security_group_id":group_id,
                        "security_group_name":group_name
                    }
                )
            vpc_id['vpc_security_groups'] = vpc_sg_group
        # pprint.pprint(VPCs)
        return VPCs
    

    async def get_aws_key_info(self):
        print("user started")
        response = self.boto3_session_token_service.get_caller_identity()
        print('User ID:', response['UserId'].split(":")[1])
        print('Account:', response['Account'])
        aws_user_details = {
            "account": response['Account'],
            "user_id": response['UserId'].split(":")[1]
            
        }

        return aws_user_details






    
    # async def get_instance_classes(self):
    #     engine = 'postgres'
    #     response = self.rds_client.describe_orderable_db_instance_options(Engine=engine)
    #     db_instance_classes = [option['DBInstanceClass'] for option in response['OrderableDBInstanceOptions']]    
    #     return list(db_instance_classes)

    # async def get_instance_classes(self):
    #     response = self.ec2.describe_instance_types(InstanceTypes=['t3.small', 't3.medium', 't3.large'])

    #     pprint.pprint(response)
    #     return list(response)
    
    
    async def get_rds_subnetgroups(self):
        # ec2 = boto3.client('ec2')
        response = self.ec2.describe_vpcs()
        VPCs = []
        for vpc in response['Vpcs']:
            vpc_id = vpc['VpcId']
            vpc_name = ''            
            for tag in vpc['Tags']:
                if tag['Key'] == 'Name':
                    vpc_name = tag['Value']
                    break
            

            VPCs.append({
                "vpc_id":vpc_id,
                "vpc_name":vpc_name
            })
        for vpc in VPCs:
            response = self.rds_client.describe_db_subnet_groups()
            subnet_group_names = []
            for subnet_group in response['DBSubnetGroups']:
                if subnet_group['VpcId'] == vpc['vpc_id']:
                    subnet_group_names.append(subnet_group['DBSubnetGroupName'])
            vpc['vpc_subnet_group'] = subnet_group_names
        return list(VPCs)

        

    







