class Project_Credentials:

    __SS_foglight_server = "10.224.103.191"
    __SS_database_name = "master"
    __SServerUsername = "FoglightMon"
    __SServerPassword = 'iU2v45eF*GyDx51N'

    __PG_postgres_server = "databaseprov.cuolghpjfqsl.us-east-1.rds.amazonaws.com"
    __PG_username = "postgres"
    __PG_password = "4S24AoHHpT4O"
    __PG_database="dbautomation"
    __PG_vsc_user = "foglightmon"
    __PG_vsc_password = "uY!w#94t4Q#S"

    __SMTP_sever = "email-smtp.us-east-1.amazonaws.com"
    __SMTP_username = "AKIAWCBZW73T547KY7JN"
    __SMTP_password = "BBRuU+eP0iS3rXpDRPbWlKeZ0bOkG2dZk574s8DtoxIX"
    __SMTP_port = 587

 
    

    
    def __init__(self):
        pass

    def get_smtp_servername(self):
        return self.__SMTP_sever
    
    def get_smtp_username(self):
        return self.__SMTP_username
    
    def get_smtp_password(self):
        return self.__SMTP_password
    
    def get_smtp_port(self):
        return self.__SMTP_port
    
     
    def getSSUsername(self):
        return self.__SServerUsername
    
    def getSSPassword(self):
        return self.__SServerPassword
    
    def get_SS_server_name(self):
        return self.__SS_foglight_server
    
    def get_SS_database_name(self):
        return self.__SS_database_name



    def get_pg_username(self):
        return self.__PG_username
    
    def get_pg_password(self):
        return self.__PG_password
    
    def get_pg_server(self):
        return self.__PG_postgres_server
    
    def get_pg_database(self):
        return self.__PG_database
    
    def get_pg_svc_user(self):
        return self.__PG_vsc_user
    
    def get_pg_svc_password(self):
        return self.__PG_vsc_password