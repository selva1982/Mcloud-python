from credentials import Project_Credentials
import psycopg2
import psycopg2.extras
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import string
import random


class DBb_helper:

    def __init__(self) -> None:
        pg_db = Project_Credentials()

        self.pg_servername = pg_db.get_pg_server()
        self.pg_dbname = pg_db.get_pg_database()
        self.pg_username = pg_db.get_pg_username()
        self.pg_password = pg_db.get_pg_password()
        self.pg_svc_username = pg_db.get_pg_svc_user()
        self.pg_svc_password = pg_db.get_pg_svc_password()

        self.ss_servername = pg_db.get_SS_server_name()
        self.ss_dbname = pg_db.get_SS_database_name()
        self.ss_username = pg_db.getSSUsername()
        self.ss_password = pg_db.getSSPassword()

        self.smtp_server = pg_db.get_smtp_servername()
        self.smtp_username = pg_db.get_smtp_username()
        self.smtp_password = pg_db.get_smtp_password()
        self.smtp_port = pg_db.get_smtp_port()

        pass

    def send_email_html(self, receipient,email_subject,email_msg):
        sender = 'noreply@modernatx.com'
        recipient = receipient + ",databaseops@modernatx.com"
        subject = email_subject
        html_body = email_msg
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = recipient
        msg['Cc'] = 'databaseops@modernatx.com'
        msg['Subject'] = subject
        email_body = MIMEText(html_body, )
        msg.attach(MIMEText(html_body, 'html'))
        smtp_server = self.smtp_server
        smtp_username = self.smtp_username
        smtp_password = self.smtp_password

        server = smtplib.SMTP(smtp_server, 587)
        server.ehlo()
        server.starttls()
        server.login(smtp_username, smtp_password)
        server.sendmail(sender, [recipient,'databaseops@modernatx.com'], msg.as_string())

        return {"msg":"Success"}



    def select_query(self, sql):
        try:
            conn = psycopg2.connect(
                        host=self.pg_servername,
                        user=self.pg_username,
                        password=self.pg_password,
                        database=self.pg_dbname,
                        port=5432)
            
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cursor.execute(sql)            
            rows = cursor.fetchall()
            conn.commit()
            conn.close()
            msg = {
                "status":"SUCCESS",
                "rows" : rows
                }
            return msg
        except Exception as e:  
            msg = {
                "status":"FAILURE",
                "err_msg" : str(e)
                }
            return msg
        
    def select_query_parameterized(self, sql, data):
        try:
            conn = psycopg2.connect(
                        host=self.pg_servername,
                        user=self.pg_username,
                        password=self.pg_password,
                        database=self.pg_dbname,
                        port=5432)
            
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cursor.execute(sql, data)            
            conn.commit()
            conn.close()
            msg = {
                "status":"SUCCESS",
                }
            return msg
        except Exception as e:  
            msg = {
                "status":"FAILURE",
                "err_msg" : str(e)
                }
            return msg
        
    async def  async_select_query(self, sql):
        try:
            # print( self.pg_servername,self.pg_dbname )
            print(sql)

            conn = psycopg2.connect(
                        host=self.pg_servername,
                        user=self.pg_username,
                        password=self.pg_password,
                        database=self.pg_dbname,
                        port=5432)
            
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cursor.execute(sql)
            rows = cursor.fetchall()
            msg = {
                "status":"SUCCESS",
                "rows" : rows
                }
            return msg
        except Exception as e:  
            msg = {
                "status":"FAILURE",
                "err_msg" : str(e)
                }
            return msg
        

    def select_query_host_option(self,sql,hostname,port,username,password):
        try:
            conn = psycopg2.connect(
                        host=hostname,
                        user=username,
                        password=password,
                        database='postgres',
                        port=port)
            
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cursor.execute(sql)
            rows = cursor.fetchall()
            msg = {
                "status":"SUCCESS",
                "rows" : rows
                }
            return msg
        except Exception as e:  
            msg = {
                "status":"FAILURE",
                "err_msg" : str(e)
                }
            return msg
        
    def select_query_host_db_option(self,sql,hostname,port,username,password,db):
        try:
            conn = psycopg2.connect(
                        host=hostname,
                        user=username,
                        password=password,
                        database=db,
                        port=port)
            
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cursor.execute(sql)
            rows = cursor.fetchall()
            msg = {
                "status":"SUCCESS",
                "rows" : rows
                }
            return msg
        except Exception as e:  
            msg = {
                "status":"FAILURE",
                "err_msg" : str(e)
                }
            return msg
        
    def SS_execute_SQl_Query(self,sql):
        server = self.ss_servername
        database = self.ss_dbname
        username = self.ss_username
        password = self.ss_password
        driver = '{ODBC Driver 18 for SQL Server}'
        connection_string = f"DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password};Encrypt=no"
       
        try:
            print("connection success")
            conn = pyodbc.connect(connection_string)            
            cursor = conn.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            columns = [column[0] for column in cursor.description]
            cursor.close()
            conn.close()
            data = []
            for row in rows:
                data.append(dict(zip(columns, row)))

            return data

        except pyodbc.Error as e:
            print("connection failed")
            return {'status': 'error', 'message': 'Error connecting to SQL Server: ' + str(e)}


    def generate_password(self):
        length = 12
        letters = string.ascii_letters     # a-z and A-Z
        digits = string.digits             # 0-9
        punctuation = string.punctuation.replace('/', '').replace('@', '').replace('"', '').replace(' ', '')  # all printable punctuation except '/', '@', '"', and ' '

        password_characters = letters + digits + punctuation
        password = ''.join(random.choice(password_characters) for i in range(length))
        return password

