from fastapi import FastAPI,Body
import os
import datetime
import json
import boto3
import psycopg2
from aws_helper import aws_Core
import asyncio
from fastapi.middleware.cors import CORSMiddleware
from db_helper import DBb_helper
import pprint
from credentials import Project_Credentials
import random
import string
from fastapi.responses import JSONResponse
import csv
from argon2 import PasswordHasher







app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'

@app.get("/")
def root():
    return {"message":"success"}

@app.post("/aws_report")
def aws_account_details(rds_data: dict = Body(...)):
    db = DBb_helper()
    if rds_data['report_type'] == 'ec2':
        select_query="select * from get_latest_inventory()"
    elif rds_data['report_type'] == 'rds':
        select_query="select * from get_rds_latest_inventory()"
    elif rds_data['report_type'] == 'aws_accounts':
        select_query="select * from aws_accounts"
    elif rds_data['report_type'] == 'backup-failure':
        select_query="select * from get_latest_backup_failure()"
    elif rds_data['report_type'] == 'backup-summary':
        select_query="select * from get_latest_backup_summary()"
    return json.dumps(db.select_query(select_query), default=str)




@app.post("/get_rds_details")
async def get_rds_details(rds_auth: dict = Body(...)):
    try:
        aws = aws_Core(rds_auth['access-key'],rds_auth['secerte-access-key'],rds_auth['aws-session-token'])
        db = DBb_helper()

        vpc_security_group_task = asyncio.create_task(aws.get_rds_vpcSecurityId())
        instance_classes_task = asyncio.create_task(db.async_select_query("select * from instance_class_table where instance_class in (\'{}\',\'{}\',\'{}\')".format('db.r5.2xlarge*','db.r5.large*','db.t3.small*')))
        # instance_classes_task = asyncio.create_task(aws.get_instance_classes())
        db_subnetgroups_task = asyncio.create_task(aws.get_rds_subnetgroups())
        key_user_details = asyncio.create_task(aws.get_aws_key_info())
        cost_center_data = asyncio.create_task(db.async_select_query("select * from db_cost_center order by sponser"))

        # Wait for all tasks to complete
        results = await asyncio.gather(vpc_security_group_task, instance_classes_task, db_subnetgroups_task, key_user_details,cost_center_data)


        # Retrieve the results
        vpc_security_group = results[0]
        instance_classes = results[1]
        db_subnetgroups = results[2]
        key_user_details = results[3]
        cost_center_data = results[4]

        aws_details = {
            "vpc_security_group": vpc_security_group,
            "db_subnetgroups": db_subnetgroups,
            "instance_classes": instance_classes,
            "key_user_details": key_user_details,
            "cost_center_data": cost_center_data

        }

        pprint.pprint(aws_details)
        return aws_details
    except Exception as e:
        pprint.pprint(str(e))
        return  {
            "result":"FAILURE",
            "result_message": str(e)
        }



@app.post("/create_rds")
def create_rds(rds_data: dict = Body(...)):

    required_keys = ['access-key', 'secerte-access-key', 'aws-session-token', 'DBInstanceClass', 
                     'Engine', 'EngineVersion', 'MasterUsername', 'AllocatedStorage', 
                     'DBSubnetGroupName', 'VpcSecurityGroupIds', 'costCenter', 'sponser', 
                     'appOwner', 'department', 'DBInstanceIdentifier']
    missing_or_empty_keys = [key for key in required_keys if key not in rds_data or not rds_data[key]]
    if missing_or_empty_keys:
        return JSONResponse(status_code=400, content={"error": "Missing or empty properties", "missing_or_empty_keys": missing_or_empty_keys})
    db = DBb_helper()
    master_user_password = db.generate_password()
    # pprint.pprint(rds_data)
    rds  = boto3.client('rds',
                                aws_access_key_id=rds_data['access-key'],
                                aws_secret_access_key=rds_data['secerte-access-key'],
                                aws_session_token=rds_data['aws-session-token']) 
    try:

        pprint.pprint(rds_data)
        if rds_data['DBInstanceClass'] == 'prod':
            if rds_data['Engine']  in ['sqlserver-se','sqlserver-ee']:
                instance_class="db.r5.2xlarge"
                MultiAZ=True
                StorageType="io1"
                IO_ops=5000
                env_tag='production'
                rds_response = rds.create_db_instance(
                DBInstanceIdentifier=str(rds_data['DBInstanceIdentifier']),
                LicenseModel='license-included',
                Engine=str(rds_data['Engine']),
                EngineVersion=str(rds_data['EngineVersion']),
                MasterUsername=str(rds_data['MasterUsername']),
                MasterUserPassword=str(master_user_password),
                AllocatedStorage=int(rds_data['AllocatedStorage']),        
                DBSubnetGroupName = str(rds_data['DBSubnetGroupName']),
                VpcSecurityGroupIds=rds_data['VpcSecurityGroupIds'],  
                DBInstanceClass=instance_class,    
                MultiAZ=MultiAZ,
                StorageType=StorageType,            
                Iops=IO_ops,
                MaxAllocatedStorage=int(rds_data['AllocatedStorage'])*2,
                BackupRetentionPeriod=int(35),
                StorageEncrypted=True,
                AutoMinorVersionUpgrade=False,
                PubliclyAccessible=False,
                DeletionProtection=True,
                Tags=[
                    {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                    {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                    {'Key': 'sponsor', 'Value': rds_data['sponser']},
                    {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                    {'Key': 'department', 'Value': rds_data['department']},
                    {'Key': 'environment', 'Value': env_tag}
                ]
                )
            elif rds_data['Engine']  in ['aurora-postgresql','aurora-mysql']:                
                instance_class="db.r5.2xlarge"
                MultiAZ=True
                IO_ops=5000
                StorageType="NA",
                env_tag='production'
                rds_response = rds.create_db_cluster(
                DBClusterIdentifier=str(rds_data['DBCluster']),
                Engine=str(rds_data['Engine']),
                EngineMode=str(rds_data['engineMode']),
                DatabaseName=str(rds_data['DBName']),
                EngineVersion=str(rds_data['EngineVersion']),
                MasterUsername=str(rds_data['MasterUsername']),
                MasterUserPassword=str(master_user_password),
                VpcSecurityGroupIds=rds_data['VpcSecurityGroupIds'],
                DBSubnetGroupName = str(rds_data['DBSubnetGroupName']),
                DeletionProtection=True,
                BackupRetentionPeriod=int(35),
                StorageEncrypted=True,
                AutoMinorVersionUpgrade=False,
                Tags=[
                        {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                        {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                        {'Key': 'sponsor', 'Value': rds_data['sponser']},
                        {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                        {'Key': 'department', 'Value': rds_data['department']},
                        {'Key': 'environment', 'Value': env_tag}
                    ]               

            )
                if str(rds_data['engineMode']) != 'serverless':
                    rds_response = rds.create_db_instance(
                    DBClusterIdentifier=str(rds_data['DBCluster']),
                    DBInstanceIdentifier=str(rds_data['DBInstanceIdentifier']),
                    Engine=str(rds_data['Engine']),
                    DBInstanceClass=instance_class,    
                    PubliclyAccessible=False,
                    Tags=[
                        {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                        {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                        {'Key': 'sponsor', 'Value': rds_data['sponser']},
                        {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                        {'Key': 'department', 'Value': rds_data['department']},
                        {'Key': 'environment', 'Value': env_tag}
                    ]
                    )



            else:
                instance_class="db.r5.2xlarge"
                MultiAZ=True
                StorageType="io1"
                IO_ops=5000
                env_tag='production'
                rds_response = rds.create_db_instance(
                DBInstanceIdentifier=str(rds_data['DBInstanceIdentifier']),
                Engine=str(rds_data['Engine']),
                EngineVersion=str(rds_data['EngineVersion']),
                MasterUsername=str(rds_data['MasterUsername']),
                MasterUserPassword=str(master_user_password),
                AllocatedStorage=int(rds_data['AllocatedStorage']),        
                DBSubnetGroupName = str(rds_data['DBSubnetGroupName']),
                DBName=str(rds_data['DBName']),
                VpcSecurityGroupIds=rds_data['VpcSecurityGroupIds'],  
                DBInstanceClass=instance_class,    
                MultiAZ=MultiAZ,
                StorageType=StorageType,            
                Iops=IO_ops,
                MaxAllocatedStorage=int(rds_data['AllocatedStorage'])*2,
                BackupRetentionPeriod=int(35),
                StorageEncrypted=True,
                AutoMinorVersionUpgrade=False,
                PubliclyAccessible=False,
                DeletionProtection=True,
                Tags=[
                    {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                    {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                    {'Key': 'sponsor', 'Value': rds_data['sponser']},
                    {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                    {'Key': 'department', 'Value': rds_data['department']},
                    {'Key': 'environment', 'Value': env_tag}
                ]
                )

        else:
            if  rds_data['Engine']  in ['sqlserver-se','sqlserver-ee']:
                if rds_data['DBInstanceClass'] == 'test':
                    instance_class="db.r5.xlarge"
                    MultiAZ=False
                    StorageType="gp2"
                    env_tag='test'
                elif rds_data['DBInstanceClass'] == 'dev':
                    instance_class="db.r5.xlarge"
                    MultiAZ=False
                    StorageType="gp2"
                    env_tag='development'

                rds_response = rds.create_db_instance(
                DBInstanceIdentifier=str(rds_data['DBInstanceIdentifier']),
                LicenseModel='license-included',
                Engine=str(rds_data['Engine']),
                EngineVersion=str(rds_data['EngineVersion']),
                MasterUsername=str(rds_data['MasterUsername']),
                MasterUserPassword=str(master_user_password),
                AllocatedStorage=int(rds_data['AllocatedStorage']),        
                DBSubnetGroupName = str(rds_data['DBSubnetGroupName']),
                VpcSecurityGroupIds=rds_data['VpcSecurityGroupIds'],  
                DBInstanceClass=instance_class,    
                MultiAZ=MultiAZ,
                StorageType=StorageType,         
                MaxAllocatedStorage=int(rds_data['AllocatedStorage'])*2,
                BackupRetentionPeriod=int(35),
                StorageEncrypted=True,
                AutoMinorVersionUpgrade=False,
                PubliclyAccessible=False,
                DeletionProtection=True,
                Tags=[
                    {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                    {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                    {'Key': 'sponsor', 'Value': rds_data['sponser']},
                    {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                    {'Key': 'department', 'Value': rds_data['department']},
                    {'Key': 'environment', 'Value': env_tag}
                ]
                )
            elif rds_data['Engine']  in ['aurora-postgresql','aurora-mysql']:                
                if rds_data['DBInstanceClass'] == 'test':
                    instance_class="db.r5.xlarge"
                    MultiAZ=False
                    StorageType="NA"
                    env_tag='test'
                elif rds_data['DBInstanceClass'] == 'dev':
                    instance_class="db.r5.xlarge"
                    MultiAZ=False
                    StorageType="NA"
                    env_tag='development'

                rds_response = rds.create_db_cluster(
                DBClusterIdentifier=str(rds_data['DBCluster']),
                Engine=str(rds_data['Engine']),
                EngineMode=str(rds_data['engineMode']),
                DatabaseName=str(rds_data['DBName']),
                EngineVersion=str(rds_data['EngineVersion']),
                MasterUsername=str(rds_data['MasterUsername']),
                MasterUserPassword=str(master_user_password),
                VpcSecurityGroupIds=rds_data['VpcSecurityGroupIds'],
                DBSubnetGroupName = str(rds_data['DBSubnetGroupName']),
                DeletionProtection=True,
                BackupRetentionPeriod=int(35),
                StorageEncrypted=True,
                AutoMinorVersionUpgrade=False,
                Tags=[
                        {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                        {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                        {'Key': 'sponsor', 'Value': rds_data['sponser']},
                        {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                        {'Key': 'department', 'Value': rds_data['department']},
                        {'Key': 'environment', 'Value': env_tag}
                    ]               

            )
                if str(rds_data['engineMode']) != 'serverless':
                    rds_response = rds.create_db_instance(
                    DBClusterIdentifier=str(rds_data['DBCluster']),
                    DBInstanceIdentifier=str(rds_data['DBInstanceIdentifier']),
                    Engine=str(rds_data['Engine']),
                    DBInstanceClass=instance_class,    
                    PubliclyAccessible=False,
                    Tags=[
                        {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                        {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                        {'Key': 'sponsor', 'Value': rds_data['sponser']},
                        {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                        {'Key': 'department', 'Value': rds_data['department']},
                        {'Key': 'environment', 'Value': env_tag}
                    ]
                    )
            else:
                if rds_data['DBInstanceClass'] == 'test':
                    instance_class="db.r5.large"
                    MultiAZ=False
                    StorageType="gp2"
                    env_tag='test'
                elif rds_data['DBInstanceClass'] == 'dev':
                    instance_class="db.t3.small"
                    MultiAZ=False
                    StorageType="gp2"
                    env_tag='development'

                rds_response = rds.create_db_instance(
                DBInstanceIdentifier=str(rds_data['DBInstanceIdentifier']),
                Engine=str(rds_data['Engine']),
                EngineVersion=str(rds_data['EngineVersion']),
                MasterUsername=str(rds_data['MasterUsername']),
                MasterUserPassword=str(master_user_password),
                AllocatedStorage=int(rds_data['AllocatedStorage']),        
                DBSubnetGroupName = str(rds_data['DBSubnetGroupName']),
                DBName=str(rds_data['DBName']),
                VpcSecurityGroupIds=rds_data['VpcSecurityGroupIds'],  
                DBInstanceClass=instance_class,    
                MultiAZ=MultiAZ,
                StorageType=StorageType,         
                MaxAllocatedStorage=int(rds_data['AllocatedStorage'])*2,
                BackupRetentionPeriod=int(35),
                StorageEncrypted=True,
                AutoMinorVersionUpgrade=False,
                PubliclyAccessible=False,
                DeletionProtection=True,
                Tags=[
                    {'Key': 'CreatedBy', 'Value': 'dbops_automation'},
                    {'Key': 'costcenter', 'Value': rds_data['costCenter']},
                    {'Key': 'sponsor', 'Value': rds_data['sponser']},
                    {'Key': 'application-owner', 'Value': rds_data['appOwner']},
                    {'Key': 'department', 'Value': rds_data['department']},
                    {'Key': 'environment', 'Value': env_tag}
                ]
                )


        rds_insert_sql = """
            SELECT insert_rds_creation_logs(
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s
            )
            """
        
        rds_creation_data = (
            rds_data['createdBy']['user_id'],
            rds_data['createdBy']['account'],
            rds_data['MasterUsername'],
            master_user_password,
            rds_data['DBInstanceIdentifier'],
            rds_data['Engine'],
            rds_data['EngineVersion'],
            str(rds_data['AllocatedStorage']),
            instance_class,
            rds_data['DBName'],
            StorageType,
            str(rds_data['AllocatedStorage']*2),
            '35',
            'True',
            'False',
            'False',
            'True'
        )

        print(rds_creation_data)

        print("inserting rds logs")
        db.select_query_parameterized(rds_insert_sql,rds_creation_data)

        return {
            "result":"SUCCESS",
            "result_message": rds_response
        }
    except Exception as e:
        return  {
            "result":"FAILURE",
            "result_message": str(e)
        }

    return response


@app.get("/get_periodic_access_SS")
def get_periodic_access_SS():    
    db = DBb_helper()

    # ss_sql_query = "select * from Audit.dbo.New_Auditdetails"
    ss_sql_query = "select * from Audit.dbo.PAR_Auditdetails"

    return db.SS_execute_SQl_Query(ss_sql_query)

@app.get("/update_periodic_access_pg")
def get_periodic_access_pg():
    db = DBb_helper()
    crd = Project_Credentials()
    rows = db.select_query("select * from postgres_active_servers")
    periodic_access_data=[]
    for server in rows['rows']:
        # sql="select \'{}\' as server_name,usename, usesuper as superuser, usecreatedb as create_db, userepl as replication from pg_catalog.pg_user where usecreatedb = true or usesuper = true or userepl = true".format(server['server_name'])

        sql="select \'{}\' as server_name,usename, usesuper as superuser, usecreatedb as create_db, userepl as replication from pg_catalog.pg_user".format(server['server_name'])

        sql_new = """
                    SELECT
                        \'{}\' as server_name,
                        a.usename,
                        a.usesuper AS superuser,
                        a.usecreatedb AS create_db,
                        a.userepl AS replication,
                        b.granted_roles
                    FROM
                        pg_catalog.pg_user a
                    left JOIN (
                        SELECT
                            c.rolname AS usename,
                            ARRAY_AGG(a.rolname) AS granted_roles
                        FROM
                            pg_roles a
                        LEFT JOIN pg_auth_members b ON
                            a.oid = b.member
                        LEFT JOIN pg_roles c ON
                            b.roleid = c.oid
                        GROUP BY
                            c.rolname) b ON a.usename = b.usename
""".format(server['server_name'])

        access_data = db.select_query_host_option(sql_new,
                                     server['server_name'],
                                     server['port'],
                                     crd.get_pg_svc_user(),
                                    crd.get_pg_svc_password())
        print("======================================================================")
        if access_data['status'] == 'SUCCESS':
            for server_data in access_data['rows']:
                print(server_data['granted_roles'])
                if server_data['granted_roles'] == None:
                    insert_audit_data = "SELECT insert_pg_audit_data(\'{}\', \'{}\', {},{},{},null)".format(server_data['server_name'],server_data['usename'],server_data['superuser'],server_data['create_db'],server_data['replication'])
                else:
                    insert_audit_data = "SELECT insert_pg_audit_data(\'{}\', \'{}\', {},{},{},ARRAY{})".format(server_data['server_name'],server_data['usename'],server_data['superuser'],server_data['create_db'],server_data['replication'], server_data['granted_roles'])
                print(insert_audit_data)
                print(db.select_query(insert_audit_data))
                periodic_access_data.append(access_data['rows'])

            
            # server_data = access_data['rows'][0]
            # insert_audit_data = "SELECT insert_data(\'{}\', \'{}\', {}, {}, {})".format(server_data['server_name'],server_data['usename'],server_data['superuser'],server_data['create_db'],server_data['replication'])
            # print(insert_audit_data)
            # print(db.select_query(insert_audit_data))
        else:
            pass
    return periodic_access_data


@app.get("/get_periodic_access_pg")
def get_periodic_access_pg():
    db = DBb_helper()
    periodic_access_data_pg = db.select_query("SELECT * FROM get_audit_data()")
    return periodic_access_data_pg

@app.get("/get_audited_periodic_access_pg")
def get_audited_periodic_access_pg():
    db = DBb_helper()
    periodic_access_data_pg = db.select_query("SELECT * FROM get_postgres_active_servers()")
    return periodic_access_data_pg




@app.post("/send_html_email")
def send_email(Email_data: dict = Body(...)):
    email = Email_data['email']
    subject = Email_data['subject']
    email_body = Email_data['email_body']
    db = DBb_helper()
    db.send_email_html(email, subject, email_body)
    return {"msg":"Email Sent Successfully"}


@app.post("/check_owned_servers_by_email")
def check_owned_servers_by_email(server_data:dict = Body(...)):
    print(server_data)
    db = DBb_helper()
    sql= "select count(1) as count from Audit.dbo.audit_server_owners where email = \'{}\'".format(server_data['emailid'])
    registered_servers_by_email = db.SS_execute_SQl_Query(sql)
    print(registered_servers_by_email[0]['count'])

    if registered_servers_by_email[0]['count'] == 0:
        return registered_servers_by_email
    else:
        letters_and_digits = string.ascii_letters + string.digits
        verification_code = ''.join((random.choice(letters_and_digits) for i in range(12)))
        print(verification_code)

        return registered_servers_by_email
    
@app.get("/get_all_par_servers")
def get_all_par_servers():
    db = DBb_helper()
    sql_query = "select * from Audit.dbo.audit_server_owners"
    return db.SS_execute_SQl_Query(sql_query)


@app.post("/get_audited_data_by_server")
def get_audited_data_by_server(server_data : dict = Body(...)):
    db = DBb_helper()
    server_sql = "SELECT * FROM Audit.dbo.PAR_Auditdetails WHERE ServerName = \'{}\' AND CONVERT(DATE, Sysdate) = (SELECT MAX(CONVERT(DATE, Sysdate)) FROM Audit.dbo.PAR_Auditdetails);".format(server_data['serverByApp'])
    
    # server_sql = "select * from Audit.dbo.New_Auditdetails where ServerName = \'{}\'".format(server_data['serverByApp'])

    print(server_sql)
    return db.SS_execute_SQl_Query(server_sql)

@app.post("/get_postgres_par_data_by_server")
def get_postgres_par_data_by_server(pg_server: dict = Body(...)):
    db = DBb_helper()
    postgres_sql = "select * from get_pg_audit_data(\'{}\')".format(pg_server['serverByApp']) 
    return db.select_query(postgres_sql)


@app.post("/rds_version_control")
def rds_version_control(rds_version_data:dict = Body(...)):
    if rds_version_data['dataType'] == 'engine':
        print()





@app.get("/get_postgres_cutsom_query")
def get_postgres_cutsom_query():
    db = DBb_helper()
    crd = Project_Credentials()
    rows = db.select_query("select * from postgres_active_servers")
    sql_new="SELECT pg_size_pretty(SUM(pg_database_size(pg_database.datname))) AS total_size FROM pg_database where datname not in ('rdsadmin')"
    for server in rows['rows']:
        access_data = db.select_query_host_option(sql_new,
                            server['server_name'],
                            server['port'],
                            crd.get_pg_svc_user(),
                           crd.get_pg_svc_password())
        print("==========================================================================")
        print(server['server_name'])
        print(access_data)

@app.get("/get_db_version")
def get_db_version():
    db = DBb_helper()
    sql="select * from rds_available_versions"
    data = db.select_query(sql)
    print(data)
    return data

@app.post("/add_db_versions")
def add_db_versions(version_data:dict= Body(...)):
    db = DBb_helper()
    pprint.pprint(version_data)
    sql_query = "SELECT add_engine_versions(%s, %s);"
    result = db.select_query_parameterized(sql_query, (version_data['engine'], version_data['engineVersions']))
    pprint.pprint(result)    
    return {"msg":"success"}

@app.post("/get_versions_for_engine")
def get_versions_for_engine(engine:dict=Body(...)):
    db = DBb_helper()
    return db.select_query("select * from rds_available_versions where engine = '{}'".format(engine['engine']))

@app.get("/get_cost_center")
def get_cost_center():
    db = DBb_helper()
    return db.select_query("select * from db_cost_center order by sponser")


#================================= BOOMI==============================================================

@app.get("/read_api_file")
def read_api_file():
    with open("api_file_1.json", 'r') as file:
        return json.load(file)
    
@app.post("/add_boomi_api")
def add_boomi_api(api_data:dict=Body(...)):
#     conn = psycopg2.connect(
#     host="databaseprov.cuolghpjfqsl.us-east-1.rds.amazonaws.com",
#     dbname="dbautomation",   
#     user="postgres",
#     password="4S24AoHHpT4O"
# )
    
    conn = psycopg2.connect(
    host="boomi-test.cndbgevosrll.us-east-1.rds.amazonaws.com",
    dbname="postgres",   
    user="postgres",
    password="abcd1234"
        )
    cur = conn.cursor()
    print("=========================================================================================================")
    pprint.pprint(api_data)
    query = """
    INSERT INTO api_data (api_group, path, method,host,body_parameter,api_description,response_details,curl_command,request_body,response_body)
    VALUES (%s, %s, %s, %s,%s,%s,%s,%s,%s,%s)    
    """
    values = (
        api_data['api-group'],
        api_data['path'],
        api_data['method'],
        api_data['host'], 
        json.dumps(api_data['body-parameters']),
        api_data['api-description'],
        api_data['response-details'], 
        api_data['curl-command'],     
        api_data['request-body'],
        api_data['response-body']
        )
    print(query, values)
    response = cur.execute(query, values)
    conn.commit()
    cur.close()
    conn.close()    
    return {"msg":"success"}

@app.post("/update_boomi_api")
def update_boomi_api(api_data:dict=Body(...)):
    # conn = psycopg2.connect(
    # host="databaseprov.cuolghpjfqsl.us-east-1.rds.amazonaws.com",
    # dbname="dbautomation",   
    # user="postgres",
    # password="4S24AoHHpT4O"
    #     )
    conn = psycopg2.connect(
    host="boomi-test.cndbgevosrll.us-east-1.rds.amazonaws.com",
    dbname="postgres",   
    user="postgres",
    password="abcd1234"
        )
    api_description = api_data.get('api-description', '')
    api_group = api_data.get('api-group', '')
    api_id = api_data.get('api_id', 0)
    body_parameters = json.dumps(api_data.get('body-parameters', {}))
    curl_command = api_data.get('curl-command', '')
    host = api_data.get('host', '')
    method = api_data.get('method', '')
    path = api_data.get('path', '')
    request_body = api_data.get('request-body', '')
    response_body = api_data.get('response-body', '')
    response_details = api_data.get('response-details', '')

    with conn.cursor() as cur:
        cur.execute("""
        SELECT update_api_data(
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
        )""", (
            method, host, body_parameters, api_description, response_details,
            curl_command, request_body, response_body, api_group, path, api_id
        ))
    conn.commit()
    conn.close()
    pprint.pprint(api_data)
    return {"msg":"success"}

@app.post("/delete_boomi_api")
def delete_boomi_api(api_body:dict=Body(...)):
    # conn = psycopg2.connect(
    # host="databaseprov.cuolghpjfqsl.us-east-1.rds.amazonaws.com",
    # dbname="dbautomation",   
    # user="postgres",
    # password="4S24AoHHpT4O"
    #     )
    conn = psycopg2.connect(
    host="boomi-test.cndbgevosrll.us-east-1.rds.amazonaws.com",
    dbname="postgres",   
    user="postgres",
    password="abcd1234"
        )
    del_cursor = conn.cursor()
    print(api_body)
    api_id =api_body.get('api_id')

    del_cursor.execute("DELETE FROM public.api_data WHERE api_id = %s", (api_id,))

    conn.commit()
    conn.close()
    return {"msg":"success"}


@app.get("/get_boomi_api_data")
def get_boomi_api_data():
    # conn = psycopg2.connect(
    # host="databaseprov.cuolghpjfqsl.us-east-1.rds.amazonaws.com",
    # dbname="dbautomation",   
    # user="postgres",
    # password="4S24AoHHpT4O"
    #     )
    conn = psycopg2.connect(
    host="boomi-test.cndbgevosrll.us-east-1.rds.amazonaws.com",
    dbname="postgres",   
    user="postgres",
    password="abcd1234"
        )
    
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    sql="select * from api_data"
    cursor.execute(sql)
    return cursor.fetchall()

@app.post("/authenticate_user")
def authenticate_user( api_body:dict = Body(...)):
    conn = psycopg2.connect(
    host="inteng-boomi.cnhpg666q4od.us-east-1.rds.amazonaws.com",
    dbname="inteng_boomi",   
    user="postgres",
    password="Nz5-U3GS#nAQxN"
        )
    
    authenticate_cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    print(api_body)
    username = api_body.get('username')
    password = api_body.get('password')
    authenticate_cursor.execute("SELECT * FROM authenticate_user(%s, %s)", (username,password))
    return authenticate_cursor.fetchall()

@app.post("/update_api_sequence")
def authenticate_user( api_body:dict = Body(...)):
        try:
            print(api_body)
            api_formatted = api_body['sequence_data']
            print(api_formatted)
            conn = psycopg2.connect(
            host="inteng-boomi.cnhpg666q4od.us-east-1.rds.amazonaws.com",
            dbname="inteng_boomi",   
            user="postgres",
            password="Nz5-U3GS#nAQxN"
                )
                
            with conn.cursor() as cur:
                for seq in api_formatted:
                    print("inside loop.. ", seq)
                    index_api = seq['value']
                    api_group = seq['key']
                    print(index_api,api_group)
                    cur.execute("SELECT update_api_group_index_value( %s,%s )", (index_api, api_group))
                    # update_sql = "update api_group_index set index_api = \'{}\' where api_group = \'{}\'".format(index_api, api_group)
                    # print(update_sql)
                    # cur.execute(update_sql)
                    conn.commit()
        except Exception as e:   
            return {
                "status": "FAILURE",
                "err_msg": str(e)
            }
        finally:
            if conn:
                conn.close()
        return {"msg": "success-sequence"}

@app.post("/create_user")
def create_user(api_body:dict = Body(...)):
    conn = psycopg2.connect(
        host="inteng-boomi.cnhpg666q4od.us-east-1.rds.amazonaws.com",
        dbname="inteng_boomi",   
        user="postgres",
        password="Nz5-U3GS#nAQxN"
            )
    pprint.pprint(api_body)
    try:
        characters = string.ascii_letters + string.digits
        password = ''.join(random.choice(characters) for i in range(8))
        salt = bcrypt.gensalt()
        encryptted_password = bcrypt.hashpw(password.encode('utf-8'), salt)
        print(encryptted_password)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO api_users (username, user_description, user_role, vendor_email, vendor_name, encrypted_password) VALUES (%s, %s, %s, %s, %s, %s)",
                    (api_body['username'], api_body['user-description'], api_body['user-role'], api_body['vendor-email'], api_body['vendor-name'], encryptted_password))

        conn.commit()
        cursor.close()
        conn.close()
        return {"msg":"success" }
    except Exception as e:
        return {
            "msg":"failure",
            "error": str(e)
        }
    
@app.get("/retrive_api_users")
def retrive_api_users():
        conn = psycopg2.connect(
        host="inteng-boomi.cnhpg666q4od.us-east-1.rds.amazonaws.com",
        dbname="inteng_boomi",   
        user="postgres",
        password="Nz5-U3GS#nAQxN"
            )
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        sql="select * from api_users"
        cursor.execute(sql)
        return cursor.fetchall()






# @app.get("/ix_prod_apps_analysis")
# def ix_prod_apps_analysis():
#     dbs = DBb_helper()
#     db_array=[]
#     hostname="ix-prod-apps-aurora.cluster-celqrbqgfqr9.us-east-1.rds.amazonaws.com"
#     username="postgres"
#     password="Bvvrt#rt$09234TgVC"
#     port=5432
#     sql_db="SELECT datname FROM pg_database where datname not in ('template0','template1','rdsadmin')"


#     data = dbs.select_query_host_option(sql_db,hostname,port,username,password)

#     db_array = []
#     csv_file = "missing_indexes.csv"
#     file_exists = os.path.isfile(csv_file)

#     for db in data['rows']:
#         try:
#             print("==============================================================")
#             print(db['datname'])
#             db_sql_query="""
#                     SELECT
#                     current_database() AS db_name,
#                     nspname AS schema,
#                     relname AS table_name,
#                     pg_size_pretty(pg_total_relation_size(C.oid)) AS table_size,
#                     pg_size_pretty(pg_indexes_size(C.oid)) AS indexes_size,
#                     pg_size_pretty(pg_total_relation_size(C.oid) - pg_relation_size(C.oid)) AS index_only_size,
#                     ROUND((pg_indexes_size(C.oid)::float / pg_total_relation_size(C.oid)::float)::numeric, 2) AS index_table_size_ratio,
#                     pg_roles.rolname as owner
#                     FROM
#                     pg_class C
#                     LEFT JOIN
#                     pg_namespace N ON (N.oid = C.relnamespace)
#                     LEFT JOIN
#                     pg_roles ON (pg_roles.oid = C.relowner)
#                     WHERE
#                     nspname NOT IN ('pg_catalog', 'information_schema') AND
#                     C.relkind = 'r'
#                     ORDER BY
#                     pg_total_relation_size(C.oid) DESC, nspname, relname

#     """
#             db_rows= dbs.select_query_host_db_option(db_sql_query,hostname,port,username,password,db['datname'])
#             print(db_rows)
#             print(db_rows['rows'])
#             db_array.append(db_rows['rows'][0])
        
#             with open(csv_file, 'a', newline='') as csvfile:
#                 fieldnames = db_rows['rows'][0].keys()
#                 writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

#                 # Write the header only if the file didn't exist yet
#                 if not file_exists:
#                     writer.writeheader()
#                     file_exists = True

#                 # Write the data rows
#                 for row in db_rows['rows']:
#                     writer.writerow(row)
#         except Exception as e:
#             print(e)

#     return db_array


        







